import java.util.Scanner;

public class RickshawFareCalculator {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter distance traveled (in km): ");
        double distance = input.nextDouble();

        System.out.print("Enter travel time (in minutes): ");
        double time = input.nextDouble();

        System.out.print("Are you a local resident? (true/false): ");
        boolean isLocal = input.nextBoolean();

        System.out.print("Is it night-time travel? (true/false): ");
        boolean isNight = input.nextBoolean();

        double baseFare = 50;           
        double perKmCharge = 20;        
        double perMinuteCharge = 2;     
        double fare = baseFare + (perKmCharge * distance) + (perMinuteCharge * time);

        if (isLocal && distance > 5) {
            fare *= 0.9; 
        }

        if (isNight) {
            fare *= 1.2;
        }

        System.out.printf("\n--- Rickshaw Fare Summary ---\n");
        System.out.printf("Distance traveled: %.2f km\n", distance);
        System.out.printf("Time taken: %.2f minutes\n", time);
        System.out.printf("Local discount applied: %b\n", isLocal && distance > 5);
        System.out.printf("Night-time surcharge applied: %b\n", isNight);
        System.out.printf("Total fare: NPR %.2f\n", fare);

        input.close();
    }
}