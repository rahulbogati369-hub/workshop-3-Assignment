public class MathOperations {
    public static void main(String[] args) {
        int a = 10;
        int b = 5;
        int x = 5;
        System.out.println("\nQuestion 2: Unary Operators");
        System.out.println("Post Increment: " + (x++));
        System.out.println("After Post Increment: " + x);
        System.out.println("Pre Increment: " + (++x)); 
        
    } 
    
}
        

