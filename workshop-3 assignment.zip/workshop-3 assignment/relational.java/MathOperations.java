public class MathOperations {
    public static void main(String[] args) {
        
        int m = 8, n = 12;
        System.out.println("\nRelational Operators:");
        System.out.println("m > n = " + (m > n));
        System.out.println("m < n = " + (m < n));
        System.out.println("m == n = " + (m == n));
        System.out.println("m != n = " + (m != n));
        
    }
    
}
