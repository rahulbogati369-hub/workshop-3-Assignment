import java.util.Scanner;

public class RickshawFare {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter distance traveled (in km): ");
        double distance = sc.nextDouble();

        System.out.print("Enter travel time (in minutes): ");
        double time = sc.nextDouble();

        System.out.print("Is the customer a local? (yes/no): ");
        boolean isLocal = sc.next().equalsIgnoreCase("yes") ? true : false;

        System.out.print("Is it night-time travel? (yes/no): ");
        boolean isNight = sc.next().equalsIgnoreCase("yes") ? true : false;

        // Base fare and charges
        double baseFare = 60;        
        double perKmCharge = 30;     
        double perMinuteCharge = 3;  

        double fare = baseFare + (perKmCharge * distance) + (perMinuteCharge * time);
        fare = (isLocal && distance > 5) ? fare * 0.9 : fare;

        fare = isNight ? fare * 1.2 : fare;

        System.out.println("\n--- Rickshaw Fare Summary ---");
        System.out.println("Distance traveled: " + distance + " km");
        System.out.println("Travel time: " + time + " minutes");
        System.out.println("Local discount applied: " + (isLocal && distance > 5 ? "Yes" : "No"));
        System.out.println("Night-time surcharge applied: " + (isNight ? "Yes" : "No"));
        System.out.printf("Total Fare: Rs. %.0f\n", fare);

        sc.close();
    }
}